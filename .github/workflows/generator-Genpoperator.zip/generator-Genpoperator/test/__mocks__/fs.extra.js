const xfs = jest.genMockFromModule('fs.extra');

module.exports = xfs;
