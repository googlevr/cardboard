const log = jest.genMockFromModule('loglevel');

module.exports = log;
